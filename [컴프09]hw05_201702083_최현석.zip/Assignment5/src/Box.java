class Box {
	
	private int A,B,C,volume;
	
	public int getA() { return A;}
	
	public void setA() { A=10;}
	
	public int getB() { return B;}
	
	public void setB(){	B= 20;}
	
	public int getC() { return C;}
	
	public void setC(){	C=50;}

	public int getVolume() {
		return volume; 
	}
	public void setVolume() {
		// TODO Auto-generated method stub
	volume = A*B*C;
	}

}
