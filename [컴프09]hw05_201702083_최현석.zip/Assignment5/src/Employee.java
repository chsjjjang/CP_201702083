
public class Employee {
	private String A,B;
	private int C;
	
	public String getname(){
		return A;
		
	}
	public void setname() {
		// TODO Auto-generated method stub
		A = "Tom";
	}
	public String getphonenumber(){
		return B;
		
	}
	public void setphonenumber() {
		// TODO Auto-generated method stub
		B = " 010 1111 1111";
	}
	public int getpay(){
		return C;
	}
	public void setpay() {
		// TODO Auto-generated method stub
		C = 10000;
	}

}
