
public class Dogtest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Dog grr1 = new Dog("����", "Ǫ��", 1);
		Dog grr2 = new Dog("����", 2);

		System.out.println(grr1.getName() + " " + grr1.getBreed());
		System.out.println(grr2.getName() + " " + grr2.getAge());

	}

}
